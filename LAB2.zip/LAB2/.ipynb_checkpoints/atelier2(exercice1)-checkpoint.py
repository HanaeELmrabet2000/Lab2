import re
from word2number import w2n
#noise_words est liste de mots qui ne doivent pas faire partie du nom du produit,
#noise_words supprimer toutes les occurences en utilisant re.sub
#strip pour la suppression des epaces 
def clean_product_name(product):
    # Enlever les mots superflus qui ne font pas partie du nom du produit
    noise_words = ['kilos of', 'for', 'with', 'a kilogram', 'each', 'dollars', '$']
    for noise in noise_words:
        product = re.sub(r'\b' + noise + r'\b', '', product)
    return product.strip()
#pour chaque mot dans word on essaie de la convertir en nmbr avec w2n.word_to_num
#si cela réussi on l'ajoute dans la chaine converted_words sinon ajoute le mot original
def convert_numbers_in_text(text):
    # Convertir les mots représentant des nombres en chiffres
    words = text.split()
    converted_words = []
    for word in words:
        try:
            number = w2n.word_to_num(word)
            converted_words.append(str(number))
        except ValueError:
            converted_words.append(word)
    return ' '.join(converted_words)
#fonction pour generer une facture 
#convert_numbers_in_text pour convertir les mots représentatn des chiffres 
#stocke le texte dans converted_text
def generate_bill(text):
    # Convertir les mots en chiffres
    converted_text = convert_numbers_in_text(text)
    
    # Expression régulière pour extraire les données
    pattern = r'(\d+)\s+(.*?)\s+(\d+(?:[.,]\d+)?)\s*(?:dollars?|each|\$|a kilogram)?'
#re.findall pour trouver les correspondances du modéle dans le texte converti et stocke les résultat dans items
    # Rechercher les articles dans le texte converti
    items = re.findall(pattern, converted_text)
#si items est vide alors le modéel regex n'a trouvé aucun article
    if not items:
        # Si aucun article n'est trouvé, renvoyer un message d'erreur
        print("Aucun article n'a été trouvé dans le texte. Veuillez fournir des données correctes.")
        return
#pour chaque items crérer un tuple ontenant (quatité , nom du prouit nettoye , le prix convertie)
    # Nettoyer et préparer les données pour le reçu
    cleaned_items = [
        (int(item[0]), clean_product_name(item[1]), float(item[2].replace(',', '.')))
        for item in items
    ]

    # Afficher le reçu avec un en-tête
    print("\nGenerated Bill:")
    print("{:<20} {:<10} {:<10} {:<10}".format("Product", "Quantity", "Unit Price", "Total Price"))
#pour chaque element de cleande_items calcuel le prix total (QE*PT)
    # Calculer et afficher les lignes du reçu
    for quantity, product, unit_price in cleaned_items:
        total_price = quantity * unit_price
        print("{:<20} {:<10} {:.2f} {:.2f}".format(product, quantity, unit_price, total_price))

# Demander à l'utilisateur de fournir un texte décrivant des achats
user_input = input("Veuillez entrer les détails de vos achats : ")
generate_bill(user_input)
